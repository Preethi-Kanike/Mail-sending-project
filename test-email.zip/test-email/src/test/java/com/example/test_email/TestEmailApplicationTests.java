package com.example.test_email;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestEmailApplicationTests {

	@Test
	void contextLoads() {
	}

}
