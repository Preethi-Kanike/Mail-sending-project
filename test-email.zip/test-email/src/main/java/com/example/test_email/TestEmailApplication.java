package com.example.test_email;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestEmailApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestEmailApplication.class, args);
	}

}
